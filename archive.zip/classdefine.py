class data:
	def create(self):
		print("creating data")
	def update(self):
		print("updating data")
	def delete(self):
		printf("removing data")

customerData=data()
customerData.create()
customerData.update()
customerData.delete()

counter=0 (instance of the int class)
labeled the int class instance as counter...
