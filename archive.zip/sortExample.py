def mian():
	print(sorted([1,4,5,7,3,6]))
main()